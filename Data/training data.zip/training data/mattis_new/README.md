# Mattis Cognates (2)



## Chinese-180-18

* The symbol `❷`, `@`, `[`, and `]` has been removed from the transcription
  output.
* Non-superscript digits are converted to their superscript counterparts. There
  is an exception: `ɕye8¹` is replaced with `ɕye⁵¹` (there are no other digits
  greater than 5 in the dataset).
* The symbol `，` is interpreted as separator: only the portion of the
  transcription up to the symbol is included in the output.
* The transcription `sĩã⁵¹₅₅laŋ²⁴ > siaŋ²⁴` has been changed to `sĩã⁵¹₅₅laŋ²⁴`.
* Transcriptions are lowercased (only `Sῃ⁵⁵` is affected).



